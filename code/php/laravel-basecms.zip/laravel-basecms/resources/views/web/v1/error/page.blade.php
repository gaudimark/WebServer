@extends('web.v1.base.admin')
@section('title', '错误信息')
@section('container')
    @parent
    <section class="app-content">
        <div class="m-b-xl">
            <h1 style="font-size: 48px;">{{ $title }}</h1>
            <br />
            <br />
            <br />
        </div>
    </section><!-- .app-content -->
@stop