<?php

    return [
        'juhe_appid' => env('JUHE_APPID', NULL),
    ];