<?php
$data = [
    [
        'hex' => '#FFAE42',
        'label' => '黄色',
        'rgb' => '(255, 174 ,66)'
    ],
    [
        'hex' => '#FFAE42',
        'label' => '率色',
        'rgb' => '(255, 174 ,66)'
    ],
    [
        'hex' => '#FFAE42',
        'label' => '啊色',
        'rgb' => '(255, 174 ,66)'
    ],
    [
        'hex' => '#FFAE42',
        'label' => '吧色',
        'rgb' => '(255, 174 ,66)'
    ],

];
echo json_encode($data);