export default {
  site: 'http://manger.test/'
}
