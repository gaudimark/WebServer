// 生产环境配置
module.exports = {
  site: 'http://back.ynxpyz.cn'  // 文件上传服务器地址
}
