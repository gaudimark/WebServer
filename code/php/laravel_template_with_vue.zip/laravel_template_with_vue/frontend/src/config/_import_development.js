// 开发环境配置
module.exports = {
   site: 'http://back.test'  // 文件上传服务器
}
