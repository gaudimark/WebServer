<?php

namespace App\Models;


class Session extends Model
{
    //
    protected $fillable = ['year', 'team', 'remark', 'one', 'two', 'three'];
}
