define({
  "name": "后台管理系统",
  "version": "1.0.0",
  "description": "通用管理后台 带权限设置",
  "title": "通用后台管理系统",
  "url": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-02-19T14:05:55.277Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
