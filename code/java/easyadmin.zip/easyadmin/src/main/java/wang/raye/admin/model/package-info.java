/**
 * 
 */
/**
 * 后台管理的实体bean
 * @author Raye
 *
 */
package wang.raye.admin.model;