/**
 * 
 */
/**
 * 配置相关的包
 * @author Raye
 * @since 2016年10月7日17:14:42
 */
package wang.raye.admin.config;