/**
 * 
 */
/**
 * 数据库业务接口包
 * @author Raye
 * @since 2016年12月1日17:35:28
 */
package wang.raye.admin.service;